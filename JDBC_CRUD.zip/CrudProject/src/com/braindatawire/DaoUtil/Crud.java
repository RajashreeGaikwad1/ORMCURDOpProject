package com.braindatawire.DaoUtil;

import java.beans.Statement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import org.omg.PortableServer.IdAssignmentPolicy;

public class Crud {
	public static void main(String[] args) throws SQLException {
		
	try {
		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection con= DriverManager.getConnection("jdbc:mysql://localhost:3306/sakila","root","1234");
		
		String sql="Create table Product(pid int(20)primary key, pname varchar (30), qunatity varchar(45), price varchar (40))"; 
		
		java.sql.Statement smt=con.createStatement();
		smt.execute(sql);
		smt.cancel();
		smt.close();
		
		
	} catch (ClassNotFoundException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	
	    System.out.println("Table Create Sucessfully......");
	
	}
}
