package com.braindatawire.client;

import java.sql.SQLException;
import java.util.Scanner;

import javax.sql.rowset.JdbcRowSet;
import javax.swing.text.DefaultEditorKit.InsertBreakAction;

import com.braindatawire.serviceI.I;
import com.braindatawire.serviceImpl.Service;

public class Test {
	public static void main(String[] args) throws Exception {
		
		I s=new Service() {};
		
		Scanner sc=new Scanner(System.in);
		
		System.out.println("---Using Jdbc Statement---");
		System.out.println("Menu");
		
		while(true)
		{
		System.out.println("1.Insert Data");
		System.out.println("2.Upadate Data");
		System.out.println("3.Select Data");
		System.out.println("4.Delete Data");
		System.out.println("5.Exit");
		System.out.println("Enter Your Choice");
		
		int ii=sc.nextInt();
		switch(ii)
		{
		case 1:s.insertData();
		break;
		
		case 2:s.updateData();
		break;
		
		case 3:s.selectData();
		break;
		
		case 4:s.deleteData();
		break;
		
		case 5: System.out.println("Exit");
		break;
		
		}
		
		}
	}

}
