package com.braindatawire.serviceI;

import java.sql.SQLException;

public interface I {
	 void insertData() throws Exception;
	 void updateData() throws SQLException;
	 void selectData();
	 void deleteData() throws SQLException;

}
