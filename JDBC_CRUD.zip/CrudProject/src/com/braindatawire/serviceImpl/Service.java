package com.braindatawire.serviceImpl;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

import com.braindatawire.serviceI.I;

public abstract class Service implements I {
	
	Scanner sc=new Scanner(System.in);
	
	public void insertData() throws Exception
	{
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con= DriverManager.getConnection("jdbc:mysql://localhost:3306/sakila","root","1234");
			
		//	String sql="Create table EInformation(id int(20)primary key, name varchar (30), Email varchar(40), Country varchar(45),address varchar (40))"; 
			System.out.println("Enter How Many Product want to Insert");
			int n=sc.nextInt();
			for(int i=1; i<=n; i++)
			{
			System.out.println("Enter Product pid");
			int pid1=sc.nextInt();
			
			System.out.println("Enter Product pname");
			String nm1=sc.next();
			
			System.out.println("Enter Product quantity");
			String mid1=sc.next();
			
			System.out.println("Enter Product price");
			String pc1=sc.next();
			
			String sql1="Insert into Product values("+pid1+",'"+nm1+"','"+mid1+"','"+pc1+"')";
			
			java.sql.Statement smt=con.createStatement();
			smt.execute(sql1);
			
			smt.cancel();
			smt.close();
			}
			
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		  System.out.println("Inset Data In Table Sucessfully......");
			  
	}

	
		   public void updateData() throws SQLException
		   {
			   
			   try {
				Class.forName("com.mysql.cj.jdbc.Driver"); 
				Connection con= DriverManager.getConnection("jdbc:mysql://localhost:3306/sakila","root","1234");
				System.out.println("How Many Product Data You Want Upadte");
				int n2=sc.nextInt();
				for(int i=1; i<=n2; i++)
				{	
				System.out.println("Enter Product pid");
				int eid2=sc.nextInt();
				System.out.println("Enter Product pname");
				String nm2=sc.next();
				System.out.println("Enter Product quantity");
				String mid2=sc.next();
				System.out.println("Enter Product price");
				String ec2=sc.next();
				
				//	String sql="Create table EInformation(id int(20)primary key, name varchar (30), Email varchar(40), Country varchar(45),address varchar (40))"; 

			    String sql2= "Update Product set pname='"+nm2+"',quantity='"+mid2+"',price='"+ec2+"'where pid="+eid2+"";
				System.out.println(sql2);
				java.sql.Statement smt=con.createStatement();
				smt.execute(sql2);
				}
				
				con.close();
				
				
				
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
				  System.out.println("Update Data In Table Sucessfully......");

	}
				                  
				public void selectData()
				{
					try {
						Class.forName("com.mysql.cj.jdbc.Driver");
						Connection con= DriverManager.getConnection("jdbc:mysql://localhost:3306/sakila","root","1234");
						
						String sql3="select * from Product";
						
						Statement smt=con.createStatement();
						
						ResultSet rs=smt.executeQuery(sql3);
						
						while(rs.next())
						{
							System.out.println(rs.getInt(1));
							System.out.println(rs.getString(2));
							System.out.println(rs.getString(3));
							System.out.println(rs.getString(4));
							System.out.println(rs.getString(5));
						}
					}
						
					 catch (Exception e) {
						// TODO: handle exception
					}
				
					}
	
				public void deleteData() throws SQLException
				{
					try {
						Class.forName("com.mysql.cj.jdbc.Driver");
					
					Connection con= DriverManager.getConnection("jdbc:mysql://localhost:3306/sakila","root","1234");
					
				//	String sql="Create table EInformation(id int(20)primary key, name varchar (30), Email varchar(40), Country varchar(45),address varchar (40))"; 
					System.out.println("How Many Product Data You Want Delete");
					int n4=sc.nextInt();
					for(int i=1; i<=n4; i++)
					{
					System.out.println("Enter Product Id");
					int eid4=sc.nextInt();
					
					String sql4="delete from Product where pid="+eid4+"";
					System.out.println(sql4);
				}
					}
				catch (ClassNotFoundException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				}	
				
}
				
		   
		    
		    
		    
	
	 
	 
	 


	

